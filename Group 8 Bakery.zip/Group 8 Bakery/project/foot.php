</main>

    <footer class="mt-5 p-3 bg-dark text-white text-center">
        Developed by <strong>Group 8</strong>
        Copyrighted <?= date('Y') ?>
    </footer>

</body>
</html>